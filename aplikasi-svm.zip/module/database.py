# import pymysql

# def connect():    
#     return pymysql.connect(host="localhost", user="root", password="", database="aplikasi_svm", charset='utf8mb4')